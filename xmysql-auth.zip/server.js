const login = require('./login')
const express = require('express')
const api = require('./api')

const app = express()
const port = 8080

app.all('/api/*', (req, res) => {

    api.xmysql(req, res)
})
app.all('/login', (req, res) => {
    login.init(req, res); 
});

app.get('/', (req, res) => {
    res.send('Hello WORLD')
})

app.listen(port, () => console.log(`Example app listening on port ${port}!`))